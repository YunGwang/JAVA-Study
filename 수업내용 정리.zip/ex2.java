
public class ex2 {
	

	public static void main(String args[]){	
	
		
		int a, b, c, d, e;
		a = 0;
		e = 100000000;
		
		while(true){
			
			a++;
			
		for (b=1; b<20; b++)
		{
			
			for (d=0; d<80; d++)
				if(d<80)
			System.out.println(" ");
				else
			System.out.println("�ȳ�");
			
			for (c=0; c<a; c++)
			System.out.print("\t");
			System.out.println("�ȳ�");
			
			for (c=e-b; c>0; c--);
			System.out.print(" ");
			
			
		}
	}}}
